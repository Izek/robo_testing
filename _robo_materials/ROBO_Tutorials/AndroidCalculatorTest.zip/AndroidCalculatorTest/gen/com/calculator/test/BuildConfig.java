/** Automatically generated file. DO NOT MODIFY */
package com.calculator.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}